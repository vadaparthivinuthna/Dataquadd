package com.example.Spring_inf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInfApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInfApplication.class, args);
	}

}
