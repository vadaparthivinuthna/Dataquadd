package com.example.Spring_inf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInfApplicationTests {

	@Test
	void contextLoads() {
	}

}
